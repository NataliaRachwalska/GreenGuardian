package com.anychart.graphics.vector;

/**
 * Any fill.
 */
public interface Fill {

    String getJsBase();

}