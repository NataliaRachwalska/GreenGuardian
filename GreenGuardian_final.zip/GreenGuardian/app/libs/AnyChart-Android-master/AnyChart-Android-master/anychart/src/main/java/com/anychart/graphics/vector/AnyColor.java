package com.anychart.graphics.vector;

/**
 * A shortcut for fill or stroke or patternFill.
 */
public interface AnyColor {

    String getJsBase();

}