package com.anychart.graphics.vector;

/**
 * Any color fill.
 */
public interface ColoredFill {

    String getJsBase();

}